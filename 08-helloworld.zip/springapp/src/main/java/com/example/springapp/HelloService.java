package com.example.springapp;

public class HelloService {
	public String sayHello() {
		return "Hello world from Spring!";
	}

}
