package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorld {

	public static void main(String[] args) {
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml"))
		{
           HelloService service=context.getBean("hello", HelloService.class);
           System.out.println(service.sayHello());
		}
	}

}
