package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.services.InfoTrafficComponent.Traffic;
import com.example.demo.services.NewsComponent.Item;

@Service(value="info")
public class InformationService {
	
	@Autowired
	private NewsComponent newsComponent;
	
	@Autowired
	private WeatherComponent weatherComponent;
	
	@Autowired
	private InfoTrafficComponent infoTrafficComponent;

	public int getCurrentTemperature() {
		return weatherComponent.getTemperature();
	}
	
	public int getNewsCount() {
		return newsComponent.getNews().size();
	}
	
	public List<Item> getNews() {
		return newsComponent.getNews();
	}
	
	public Traffic getTrafficInfo() {
		return infoTrafficComponent.getTrafficInfo();
	}


}
