package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloWorld {

	public static void main(String[] args) {
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml"))
		{
           IHelloService service=(IHelloService) context.getBean("helloTime");
           System.out.println(service.sayHello());
		}
	}

}
