package com.example.springapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="info")
public class InformationService {
	
	@Autowired
	private NewsComponent newsComponent;
	
	@Autowired
	private WeatherComponent weatherComponent;

	public int getCurrentTemperature() {
		return weatherComponent.getTemperature();
	}
	
	public int getNewsCount() {
		return newsComponent.getNews().size();
	}


}
