package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@GetMapping("/")
	@ResponseBody
	public String home() {
		return " ";
	}
	
	@PostMapping("/")
	@ResponseBody
	public String homePost() {
		return "<h1>Hello world! (Richiesta POST)</h1>";
	}

}








