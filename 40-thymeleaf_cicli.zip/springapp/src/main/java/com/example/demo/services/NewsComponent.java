package com.example.demo.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class NewsComponent {
	
	public class Item{
		private String title;
		private String body;
		private LocalDateTime dateTime;
		
		public Item(String title, String body, LocalDateTime dateTime) {
			this.title = title;
			this.body = body;
			this.dateTime = dateTime;
		}
		
		public String getTitle() {
			return title;
		}
		public String getBody() {
			return body;
		}
		public LocalDateTime getDateTime() {
			return dateTime;
		}
		
		
	} 
	
	public NewsComponent() {
		this.news=new ArrayList<Item>();
		this.news.add(new Item("Il Milan in testa alla classifica", 
				"Il Milan vince in casa ed � ancora primo",
				LocalDateTime.of(2021, 4, 15, 8, 10)));
		this.news.add(new Item("Arrestato il criminale Guido Rossi", 
				"Famoso criminale arrestato",
				LocalDateTime.of(2021, 4, 15, 8, 12)));
		this.news.add(new Item("Volano le Borse mondiali", 
				"Rialzi per Tokyo e Hong Kong",
				LocalDateTime.of(2021, 4, 15, 8, 15)));
	}
	
	private List<Item> news;
	
	public List<Item> getNews(){
		return news;
	}
	
	
	
	
	
	
}
