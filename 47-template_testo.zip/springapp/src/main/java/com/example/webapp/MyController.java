package com.example.webapp;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController{
	
	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("company_name","Designer per te");
		return "index";
	}
   
}








