package com.example.demo;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController implements ErrorController{
	
	@RequestMapping("/")
	public String home(Model model) {
		Message message=new Message("Buongiorno dal vostro Model!");
		model.addAttribute("mex", message);
		return "primapagina";
	}
	
	@RequestMapping("/error")
	public String errore() {
		return "errore";
	}
	

}








