package com.example.demo.services;

import org.springframework.stereotype.Component;

@Component
public class InfoTrafficComponent {
	
	public enum Traffic{
		HIGH,
		MEDIUM,
		LOW
	}
	
	Traffic getTrafficInfo() {
		return Traffic.HIGH;
	}
}
