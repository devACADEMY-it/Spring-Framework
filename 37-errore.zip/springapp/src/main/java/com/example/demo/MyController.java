package com.example.demo;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController implements ErrorController{
	
	@RequestMapping("/")
	public String home() {
		return "primapagina";
	}
	
	@RequestMapping("/error")
	public String errore() {
		return "errore";
	}
	

}








