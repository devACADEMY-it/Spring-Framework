package com.example.demo;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@RequestMapping("/")
	@ResponseBody
	public String home() {
		return "<h1>Hello world!</h1>";
	}
	
	@RequestMapping("/greeting")
	@ResponseBody
	public String optionalParam(@RequestParam(required=true) String name) {
		return "<h1>Ciao "+name+"</h1>";
	}
	
	@RequestMapping("/list")
	@ResponseBody
	public String paramsList(@RequestParam(required=true) List<String> names) {
		StringBuffer response=new StringBuffer();
		response.append("<ul>");
		names.forEach(n -> {
			response.append("<li>"+n+"</li>");
		});
		response.append("</ul>");
		return response.toString();
	}

}








