package com.example.demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	// AB345TT
	
	@GetMapping("/checkcode")
	@ResponseBody
	public String checkCode(@RequestParam(required=true) String code) {
		Pattern pattern =Pattern.compile("^[A-Z]{2}\\d{3}[A-Z]{2}$");
		Matcher matcher =pattern.matcher(code);
		if (matcher.find()) {
			return "<h1>Il codice "+code+" è VALIDO</h1>";
		}
		else
			return "<h1>Il codice "+code+" è NON VALIDO</h1>";
	}
	

}








