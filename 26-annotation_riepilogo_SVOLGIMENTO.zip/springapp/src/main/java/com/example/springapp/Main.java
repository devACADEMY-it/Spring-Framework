package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.springapp.services.InformationService;

public class Main {

	public static void main(String[] args) {
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml"))
		{
          InformationService service=(InformationService) context.getBean("info");
          System.out.println("La temperatura attuale � di "+service.getCurrentTemperature()+" �C");
          System.out.println("Sono presenti "+service.getNewsCount()+" nuove notizie");
          
          switch(service.getTrafficInfo()) {
             case HIGH:
            	 System.out.println("Traffico ELEVATO");
            	 break;
             case MEDIUM:
            	 System.out.println("Traffico NON ELEVATO");
            	 break;
             case LOW:
            	 System.out.println("Traffico ASSENTE");
          }
		}
	}

}
