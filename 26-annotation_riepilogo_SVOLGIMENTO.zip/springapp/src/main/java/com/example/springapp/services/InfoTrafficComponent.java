package com.example.springapp.services;

import org.springframework.stereotype.Component;

@Component
public class InfoTrafficComponent {
	
	public enum Traffic{
		HIGH,
		MEDIUM,
		LOW
	}
	
	Traffic getTrafficInfo() {
		return Traffic.LOW;
	}
}
