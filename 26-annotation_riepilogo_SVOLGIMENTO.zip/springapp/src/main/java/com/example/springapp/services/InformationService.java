package com.example.springapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springapp.services.InfoTrafficComponent.Traffic;

@Service(value="info")
public class InformationService {
	
	@Autowired
	private NewsComponent newsComponent;
	
	@Autowired
	private WeatherComponent weatherComponent;
	
	@Autowired
	private InfoTrafficComponent infoTrafficComponent;

	public int getCurrentTemperature() {
		return weatherComponent.getTemperature();
	}
	
	public int getNewsCount() {
		return newsComponent.getNews().size();
	}
	
	public Traffic getTrafficInfo() {
		return infoTrafficComponent.getTrafficInfo();
	}


}
