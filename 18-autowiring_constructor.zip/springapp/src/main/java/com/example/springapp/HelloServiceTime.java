package com.example.springapp;

public class HelloServiceTime implements IHelloService{

	private TimeService timeService;
	
	public HelloServiceTime(TimeService timeService) {
		this.timeService=timeService;
	}
	
	@Override
	public String sayHello() {
		return "Hello world .... sono le ore "+timeService.generateTimeInfo();
	}
	
}
