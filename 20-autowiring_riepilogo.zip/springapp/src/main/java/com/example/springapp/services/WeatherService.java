package com.example.springapp.services;

public class WeatherService {
	
	public int getTemperature() {
		return 20;
	}

}
