package com.example.springapp.services;

public class InformationService {
	
	private NewsService newsService;
	private WeatherService weatherService;
	
	public int getCurrentTemperature() {
		return weatherService.getTemperature();
	}
	
	public int getNewsCount() {
		return newsService.getNews().size();
	}

	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}

	public void setWeatherService(WeatherService weatherService) {
		this.weatherService = weatherService;
	}
	
	

}
