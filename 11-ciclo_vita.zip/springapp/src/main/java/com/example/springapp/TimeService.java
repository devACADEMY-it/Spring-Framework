package com.example.springapp;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TimeService {
	
	private DateTimeFormatter formatter;
	
	public String generateTimeInfo() {
		return formatter.format(LocalTime.now());
	}
	
	public TimeService(String format) {
		formatter=DateTimeFormatter.ofPattern(format);
	}
	
	public void startTimeService() {
		System.out.println("*** Servizio in avvio...");
	}
	
	public void stopTimeService() {
		System.out.println("... servizio in chiusura ***");
	}

}
