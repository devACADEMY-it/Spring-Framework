package com.example.springapp;

public class HelloService implements IHelloService{
	
	private String message;
	
	public String sayHello() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message=message;
	}

}
