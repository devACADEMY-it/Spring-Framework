package com.example.springapp;

public class HelloServiceTime implements IHelloService{

	private TimeService timeService;
	
	@Override
	public String sayHello() {
		return "Hello world .... sono le ore "+timeService.generateTimeInfo();
	}

	public void setTimeService(TimeService timeService) {
		this.timeService = timeService;
	}

	public void startTimeService() {
		System.out.println("... creazione di HelloServiceTime");
	}
	
	public void stopTimeService() {
		System.out.println("... distruzione di HelloServiceTime");
	}
}
