package com.example.springapp;

public interface IHelloService {
	String sayHello();
}
