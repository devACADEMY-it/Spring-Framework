package com.example.springapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="info")
public class InformationService {
	
	private NewsComponent newsComponent;
	private WeatherComponent weatherComponent;
	
	public InformationService() {
		System.out.println("Costruttore senza parametri!");
	}
	
	@Autowired
	public InformationService(NewsComponent newsComponent, WeatherComponent weatherComponent) {
		this.newsComponent = newsComponent;
		this.weatherComponent = weatherComponent;
	}

	public int getCurrentTemperature() {
		return weatherComponent.getTemperature();
	}
	
	public int getNewsCount() {
		return newsComponent.getNews().size();
	}


}
