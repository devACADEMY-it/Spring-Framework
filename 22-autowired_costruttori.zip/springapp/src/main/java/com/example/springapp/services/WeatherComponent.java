package com.example.springapp.services;

import org.springframework.stereotype.Component;

@Component
public class WeatherComponent {
	
	public int getTemperature() {
		return 20;
	}

}
