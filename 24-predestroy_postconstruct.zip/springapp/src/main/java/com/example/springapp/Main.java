package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.springapp.services.InformationService;

public class Main {

	public static void main(String[] args) {
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml"))
		{
          InformationService service=(InformationService) context.getBean("info");
          System.out.println("La temperatura attuale � di "+service.getCurrentTemperature()+" �C");
          System.out.println("Sono presenti "+service.getNewsCount()+" nuove notizie");
		}
	}

}
