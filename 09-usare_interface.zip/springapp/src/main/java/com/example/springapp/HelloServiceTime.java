package com.example.springapp;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class HelloServiceTime implements IHelloService{

	private DateTimeFormatter formatter=DateTimeFormatter.ofPattern("HH:mm");
	
	private String generateTimeInfo() {
		return formatter.format(LocalTime.now());
	}
	
	@Override
	public String sayHello() {
		return "Hello world .... sono le ore "+generateTimeInfo();
	}

}
