package com.example.springapp;

public class HelloService implements IHelloService{
	public String sayHello() {
		return "Hello world from Spring!";
	}

}
