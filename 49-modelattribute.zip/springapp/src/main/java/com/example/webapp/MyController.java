package com.example.webapp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController{
	
	@ModelAttribute("company_name")
	public String getCompanyName() {
		return "Designer per te!";
	}
	
	@RequestMapping("/")
	public String home(Model model) {
		return "index";
	}
	
	@PostMapping("/contactus")
	public String contactus(@RequestParam("Name") String name,
			@RequestParam("Email") String email,
			@RequestParam("Message") String message) {
		try {
			Files.writeString(Path.of("messages.txt"), 
					name+";"+email+";"+message+System.lineSeparator(), 
					StandardOpenOption.CREATE, 
					StandardOpenOption.APPEND);
		}
		catch(IOException io) {
			// gestione dell'eccezione
		}
		return "index";
	}
   
}








