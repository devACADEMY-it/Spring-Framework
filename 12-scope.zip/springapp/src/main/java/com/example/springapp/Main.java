package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml"))
		{
			for (int i=0; i<10; i++) {
			    Bean bean=context.getBean("bean", Bean.class);
			    System.out.println(bean.hashCode());
			}
		} 
		
	}

}
