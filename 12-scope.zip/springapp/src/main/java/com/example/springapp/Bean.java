package com.example.springapp;

public class Bean {
	
	public Bean() {
		System.out.println("Bean creato...");
		}

}
