package com.example.demo.services;

import org.springframework.stereotype.Component;

@Component
public class WeatherComponent {
	
	public int getTemperature() {
		return 20;
	}

}
