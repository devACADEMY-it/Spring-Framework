package com.example.springapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="info")
public class InformationService {
	
	private NewsComponent newsComponent;
	private WeatherComponent weatherComponent;
	
	public int getCurrentTemperature() {
		return weatherComponent.getTemperature();
	}
	
	public int getNewsCount() {
		return newsComponent.getNews().size();
	}

	@Autowired
	public void setNewsService(NewsComponent newsService) {
		this.newsComponent = newsService;
	}

	@Autowired
	public void setWeatherService(WeatherComponent weatherService) {
		this.weatherComponent = weatherService;
	}
	
	

}
