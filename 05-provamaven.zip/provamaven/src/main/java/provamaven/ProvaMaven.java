package provamaven;

import org.json.JSONObject;

public class ProvaMaven {

	public static void main(String[] args) {
		
		JSONObject jsonObject=new JSONObject();
		jsonObject.put("cognome", "Verdi");
		jsonObject.put("nome", "Daniela");
		jsonObject.put("eta", 22);
		jsonObject.put("automunito", true);
		
		System.out.println(jsonObject);
		

	}

}
