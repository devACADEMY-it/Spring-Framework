package com.example.springapp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		try(AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml")){
			 WeatherService service=context.getBean("weatherService", WeatherService.class);
			 System.out.println(service.getTemperatureMessage());
		}
	}

}
