package com.example.springapp;

public class WeatherService {
	
	private int temperature;
	
	public void generateTemperature() {
		temperature=(int)(Math.random()*18+12);
	}
	
	public String getTemperatureMessage() {
		return "Temperatura attuale: "+temperature+" �C";
	}

}
